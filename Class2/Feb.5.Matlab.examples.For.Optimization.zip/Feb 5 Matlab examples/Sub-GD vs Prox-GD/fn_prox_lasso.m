function [beta,loss_trn,loss_tst,diff_b_btrue,elpased_time] = ...
  fn_prox_lasso(X_trn,X_tst,y_trn,y_tst,lambda,beta_init,beta_gt,MAX_ITER)
%Lasso by Proximal Gradient Descent
% f(beta) =         g(beta)       +        h(beta)
%         = .5*||X*beta-y||_2^2   +   lambda*||beta||_1
%% Output variables
loss_trn = []; % loss function value for training set
loss_tst = []; % loss function value for test set
diff_b_btrue = [];
elpased_time = [];
%% For the Gradient Computation
XtX = (X_trn'*X_trn);
Xty = X_trn'*y_trn;
%% Initialization
beta = beta_init;
if size(X_trn,2) == 500 % data dimension = 500
  t = 1e-3;   
elseif size(X_trn,2) == 5000 % data dimension = 500
  t = 2.0e-5;
end
tic;
%%
diff_b_btrue = [];
for iter=1:MAX_ITER
  loss_trn     = [loss_trn, obj_f(X_trn,beta,y_trn,lambda)];
  loss_tst     = [loss_tst, obj_f(X_tst,beta,y_tst,lambda)];
  diff_b_btrue = [diff_b_btrue, norm(beta-beta_gt,2)]; 
  elpased_time = [elpased_time, toc];
  
  fprintf(1,'Prox-Gradient: f(beta)=%.2e\n', loss_trn(end));
  if iter > 510
    std_loss = std(diff_b_btrue(end-500:end));
  else
    std_loss = 1;
  end
  
  if diff_b_btrue(end) < .1 || std_loss < .1
    break;
  end
  
  % 2. Update
  beta = prox_f(XtX, Xty, t, beta, lambda);
end

%%
function [obj] = obj_f(X_,beta_,y_,lambda_)
obj = norm(X_*beta_-y_,2)^2/2 + lambda_*norm(beta_,1);

%%
function [beta_next] = prox_f(XtX_, Xty_, step_size, beta_, lambda_)
% Gradient Step
alpha = (eye(size(XtX_)) - step_size*XtX_)*beta_ + step_size*Xty_;
% Proximal Operation
idx_geq  = alpha >= lambda_;
idx_leq  = alpha <= -lambda_;
idx_btwn = abs(alpha) < lambda_;

beta_next = zeros(size(beta_));
beta_next(idx_geq)  = alpha(idx_geq)-lambda_;
beta_next(idx_leq)  = alpha(idx_leq)+lambda_;
function [beta,loss_trn,loss_tst,diff_b_btrue,elpased_time] = ...
  fn_subGD_lasso(X_trn,X_tst,y_trn,y_tst,lambda,beta_init,beta_gt,MAX_ITER)
%Lasso by Subgradient method
% beta = .5*||X*beta-y||_2^2 + lambda*||beta||_1
%% Output variables
loss_trn = []; % loss function value for training set
loss_tst = []; % loss function value for test set
diff_b_btrue = [];
elpased_time = [];
%% For the Gradient Computation
XtX = (X_trn'*X_trn);
Xty = X_trn'*y_trn;
%% Initialization
iter = 0;
beta = beta_init;
if size(X_trn,2) == 500 % data dimension = 500
  t = 2.3e-3;   
elseif size(X_trn,2) == 5000 % data dimension = 500
  t = 5e-5;
end
tic;
%% Main iteration
while norm(beta-beta_gt,2) >= .1
  % 0. Save parameters
  loss_trn     = [loss_trn, obj_f(X_trn,beta,y_trn,lambda)];
  loss_tst     = [loss_tst, obj_f(X_tst,beta,y_tst,lambda)];
  diff_b_btrue = [diff_b_btrue, norm(beta-beta_gt,2)]; 
  elpased_time = [elpased_time, toc];
  
  fprintf(1,'Subgradient: f(beta)=%.2e\n', loss_trn(end));
  
  % 1. Computer a search direction
  srch_dir = -subgrad_f(XtX,Xty,beta,lambda);
  
  % 2. Step-size
  t = t;

  % 3. Update
  beta = beta + t*srch_dir;
  
  iter = iter + 1;
  if iter > MAX_ITER
    break;
  end
end

function [obj] = obj_f(X_,beta_,y_,lambda_)
obj = norm(X_*beta_-y_,2)^2/2 + lambda_*norm(beta_,1);

function [subgrad] = subgrad_f(XtX_,Xty_,beta_,lambda_)
idx_pos  = beta_ > 0;
idx_neg  = beta_ < 0;
idx_zero = beta_ == 0;
subgrad  = XtX_*beta_ - Xty_;
subgrad(idx_pos)  = subgrad(idx_pos)  + lambda_;
subgrad(idx_neg)  = subgrad(idx_neg)  - lambda_;
subgrad(idx_zero) = subgrad(idx_zero) + lambda_*unifrnd(-1,1);
%% Problem description
% Sparse Regression (LASSO) using Subgradient vs. Proximal-gradient.
% min_{\beta}: 0.5*|| X\beta - y ||_2^2 + \lambda ||\beta||_1
clear; clc; close all;
%% Generate the data
run SparseRegressionData.m
%% Parameter setting
rng(10);
lambda   = 0.01; % regularization (LASSO)
MAX_ITER = 10000; % termination criterion
%%
X = X1;
Xtst = X1test;
y = y1;
ytst = y1test;
b = b1;
b_init = rand(size(b));

%% LASSO by Proximal Gradient Descent
[beta_prox,loss_trn_prox,loss_tst_prox,diff_b_btrue_prox,elpased_time_prox] =...
  fn_prox_lasso(X,Xtst,y,ytst,lambda,b_init,b,MAX_ITER);
%% LASSO by Sub-Gradient Algorithm
[beta_sGD,loss_trn_sGD,loss_tst_sGD,diff_b_btrue_sGD,elpased_time_sGD] =...
  fn_subGD_lasso(X,Xtst,y,ytst,lambda,b_init,b,MAX_ITER);

%% Plot1: f(beta) vs. Wall time
figure;
loglog(elpased_time_sGD,  loss_trn_sGD, '-o');  hold on;
loglog(elpased_time_prox, loss_trn_prox,'k-*'); hold off;
grid on;
title('Subgradient vs. Proximal gradient');
xlabel('wall time (sec)');
ylabel('f(\beta^{(t)})');
legend('Subgradient', 'Prox-gradient)');

%% Plot2: f(beta) vs. Iteration
figure;
loglog(loss_trn_sGD, '-o');  hold on;
loglog(loss_trn_prox,'k-*'); hold off;
grid on;
title('Subgradient vs. Proximal gradient');
xlabel('iteration');
ylabel('f(\beta^{(t)})');
legend('Subgradient', 'Prox-gradient)');

%% Plot3: Estimation -- Reconstructed support
figure;
subplot(2,1,1);
stem(beta_sGD); hold on;
stem(find(b), zeros(size(find(b))), 'rs', 'MarkerSize', 14, 'MarkerFaceColor','auto');
legend('Estimated', 'True');
title('Sub-Gradient: \beta');
subplot(2,1,2);
stem(beta_prox); hold on;
stem(find(b), zeros(size(find(b))), 'rs', 'MarkerSize', 14, 'MarkerFaceColor','auto');
legend('Estimated', 'True');
title('Proximal-Gradient: \beta');
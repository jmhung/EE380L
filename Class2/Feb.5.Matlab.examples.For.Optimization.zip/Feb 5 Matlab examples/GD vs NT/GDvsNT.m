clear;clc;close all;
%%
f = @(X_,beta_,y_,lambda_) 0.5*norm(X_*beta_-y_,2)^2+0.5*lambda_*norm(beta_,2)^2;
grad_f = @(X_,beta_,y_,lambda_) X_'*(X_*beta_-y_)+lambda_*beta_;
% min_beta : 0.5*||X*beta - y||_2^2 + 0.5*lambda*||beta||_2^2
%% 
% rng(1) % Fix the random seed point
N = 20000;
D = 4000;
X = randn(N,D);
y = randn(N,1);
beta_init = randn(D,1);
LAMBDA = 0.1;
EPSILON = 1e-2;
MAX_ITER = 50;
ALPHA = 0.3;
BETA = 0.8;
err = struct('GD',[],'NT',[]);
time = struct('GD',[],'NT',[]);
iter = struct('GD',0,'NT',0);
%% Gradient Descent
beta = beta_init;
step_size = 1/(max(eig(X'*X))+LAMBDA); % Choose the step size
tic;
while 1
  % Store Information
  iter.GD = iter.GD+1;
  time.GD = [time.GD, toc];
  err.GD = [err.GD, f(X,beta,y,LAMBDA)]; % f(beta)-f(beta*)=f(beta)
  
  % Gradient Descent Update
  step_direction = -grad_f(X,beta,y,LAMBDA);
  beta = beta + step_size*step_direction;
  
  % Termination Condition
  if err.GD(end) < EPSILON || iter.GD >= MAX_ITER
    break
  end
end
%% Newton Method
beta = beta_init;
step_size = 1;
tic;
while 1
  % Store Information
  time.NT = [time.NT, toc];
  iter.NT = iter.NT+1;
  err.NT = [err.NT, f(X,beta,y,LAMBDA)]; % f(beta)-f(beta*)=f(beta)
  
  % Gradient Descent Update
  step_direction = -(X'*X+LAMBDA*eye(D))\grad_f(X,beta,y,LAMBDA);
  
  % Newton Update
  beta = beta + step_size*step_direction;
  if err.NT(end) < EPSILON || iter.NT >= MAX_ITER
    break
  end
end
%%
figure;
subplot(2,1,1);
loglog(1:iter.GD, err.GD, '-o');hold on;
loglog(1:iter.NT, err.NT, '-*');
xlabel('Iteration');
ylabel('f(beta)-f*(\beta)');
legend('Gradient Descent','Newton');
subplot(2,1,2);
loglog(time.GD, err.GD, '-o');hold on;
loglog(time.NT, err.NT, '-*');
xlabel('Eplased Time');
ylabel('f(beta)-f*(\beta)');
legend('Gradient Descent','Newton');
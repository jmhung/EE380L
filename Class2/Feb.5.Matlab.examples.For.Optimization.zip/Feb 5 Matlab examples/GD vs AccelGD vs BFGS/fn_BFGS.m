function [B, loss_trn, loss_tst, miscls_rate, elapsed_time] = fn_BFGS(B_init,X,y,X_test,y_test,TOL,MAX_ITER,ALPHA,BETA)
%% Data format
classes = sort(unique(y),'ascend');
[N_SAMPLE, DIM] = size(X);
N_CLASS = length(classes);
%% Initialization
loss_trn = []; % loss function value for training set
loss_tst = []; % loss function value for test set
elapsed_time = []; % Elpased Time
miscls_rate = []; % Misclassification rate
B = B_init;
grad_f = fn_comp_grad(B,X,y); % Search direction
H = eye(DIM);
%%
iter = 0;
tic;
while (norm(grad_f(:),2)^2 > TOL) && (iter < MAX_ITER)
  % 0. Store the objective function value
  iter = iter+1;
  elapsed_time = [elapsed_time, toc];
  loss_trn = [loss_trn, fn_comp_obj(B,X,y)];
  loss_tst = [loss_tst, fn_comp_obj(B,X_test,y_test)];
  [~, y_hat] = min(X_test*B,[],2);
  miscls_rate = [miscls_rate, 1 - sum((y_hat-1) == y_test')/length(y_test)];
  fprintf(1,'BFGS: f(B)= %f\n', loss_trn(end));
  %%
  p = -H*grad_f;
  %% Line search
  t = 1;
  while fn_comp_obj(B+t*p,X,y) > fn_comp_obj(B,X,y) + ALPHA*t*trace(grad_f.'*p) ||...
        isnan(fn_comp_obj(B+t*p,X,y))
    t = BETA*t;
  end
  %% Update
  B_next = B + t*p;
  grad_f_next = fn_comp_grad(B_next,X,y);
  s = B_next - B;
  g = grad_f_next - grad_f;
  rho = 1/trace(g'*s);
  I_rys = eye(DIM) - rho*g*s';
  H = I_rys'*H*I_rys + rho*(s*s');
  B = B_next;
  grad_f = grad_f_next;
end
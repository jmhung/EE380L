function [obj] = fn_comp_obj(B,X,y)
obj = sum(sum(X.*B(:,y+1).')) + sum(log(sum(exp(-X*B),2)),1);

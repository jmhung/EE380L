function [B_grad] = fn_comp_grad(B, X, y)
global XXX CCC X_CLASS
%	Gradient of loss functoin
B_grad = X_CLASS+((exp(-B'*XXX')./(ones(CCC,1)*sum(exp(-B'*XXX'))))*(-XXX));
B_grad = B_grad.';
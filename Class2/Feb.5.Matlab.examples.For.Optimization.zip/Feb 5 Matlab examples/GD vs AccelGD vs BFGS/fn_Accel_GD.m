function [B, loss_trn, loss_tst, miscls_rate, elapsed_time] = ...
  fn_GD(B_init, X, y, X_test,y_test, TOL, ALPHA, BETA, MU, n_sample)
%% Initialization
loss_trn = []; % loss function value for training set
loss_tst = []; % loss function value for test set
elapsed_time = []; % Elpased Time
miscls_rate = []; % Misclassification rate
obj = [];
B = B_init;
LAMBDA = 0; % Accelerated GD Parameter
%%
iter = 1;
tic;
while 1
  % 0. Store the objective function value and misclassification rate
  elapsed_time = [elapsed_time, toc];
  loss_trn = [loss_trn, fn_comp_obj(B,X,y)];
  loss_tst = [loss_tst, fn_comp_obj(B,X_test,y_test)];
  [~, y_hat] = min(X_test*B,[],2);
  miscls_rate = [miscls_rate, 1 - sum((y_hat-1) == y_test')/length(y_test)];
  obj = [obj, fn_comp_obj(B,X,y)];
  % 1. Compute search direction
  p = -fn_comp_grad(B,X,y); % Search Direction
  fprintf(1,'Accelerated Gradient Descent: f(B)= %f\n', loss_trn(end));
%   fprintf(1,'||grad(f)||^2: %f\tl(B) (test): %f\t mis_cls_rate: %f\n', norm(p(:),2)^2, loss_tst(end), miscls_rate(end));
  if norm(p(:),2)^2 < TOL
    break;
  end
  % 2. Back tracking line search
  t = 1;
  while fn_comp_obj(B+t*p,X,y) > fn_comp_obj(B,X,y) - ALPHA*t*trace(p'*p) ||...
        isnan(fn_comp_obj(B+t*p,X,y))
    t = BETA*t;
  end
  % 3. Update
  LAMBDA_NEXT = (1+sqrt(1+4*LAMBDA^2))/2;
  GAMMA = (1-LAMBDA)/LAMBDA_NEXT;
  C_NEXT = B + t*p;
  if iter == 1
    B = C_NEXT;
  else
    B = (1-GAMMA)*C_NEXT + GAMMA*C;
  end
  C = C_NEXT;
  LAMBDA = LAMBDA_NEXT;
  iter = iter + 1;
end
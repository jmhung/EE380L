function [B, obj, elpased_time] = fn_GD(B_init, X, y, TOL, MAX_ITER, ALPHA, BETA)
%% Initialization
obj = [];
elpased_time = [];
B = B_init;
%%
tic;
for iter=1:MAX_ITER
  % 0. Store the objective function value
  obj = [obj, fn_comp_obj(B,X,y)];
  elpased_time = [elpased_time, toc];
  fprintf(1,'Gradient Descent: f(B)= %f\n', obj(end));
  % 1. Compute search direction
  p = -fn_comp_grad(B,X,y); % Search Direction
  if norm(p(:),2)^2 < TOL
    break;
  end
  % 2. Back tracking line search
  t = 1;
  while fn_comp_obj(B+t*p,X,y) > fn_comp_obj(B,X,y) - ALPHA*t*trace(p'*p) ||...
        isnan(fn_comp_obj(B+t*p,X,y))
    t = BETA*t;
  end
  % 3. Update
  B = B + t*p;
end
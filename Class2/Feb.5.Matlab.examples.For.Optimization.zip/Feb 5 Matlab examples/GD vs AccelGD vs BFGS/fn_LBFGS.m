function [B, loss_trn, loss_tst, miscls_rate, elapsed_time] = fn_LBFGS(B_init,X,y,X_test,y_test,TOL,MAX_ITER,ALPHA,BETA,m)
%% Data format
classes = sort(unique(y),'ascend');
[N_SAMPLE, DIM] = size(X);
N_CLASS = length(classes);
%% Initialization
loss_trn = []; % loss function value for training set
loss_tst = []; % loss function value for test set
elapsed_time = []; % Elpased Time
miscls_rate = []; % Misclassification rate
B = B_init;
grad_f = fn_comp_grad(B,X,y); % Search direction
gamma = 1;
%%
S = {};
G = {};
rho = [];
n_iter = 1;
tic;
while norm(grad_f(:),2)^2 > TOL && n_iter < MAX_ITER
  % 0. Store the objective function value
  elapsed_time = [elapsed_time, toc];
  loss_trn = [loss_trn, fn_comp_obj(B,X,y)];
  loss_tst = [loss_tst, fn_comp_obj(B,X_test,y_test)];
  [~, y_hat] = min(X_test*B,[],2);
  miscls_rate = [miscls_rate, 1 - sum((y_hat-1) == y_test')/length(y_test)];
  fprintf(1,'L-BFGS: f(B)= %f\n', loss_trn(end));
%   fprintf(1,'||grad(f)||^2: %f\tl(B) (train): %f\t mis_cls_rate: %f\n', norm(grad_f(:),2)^2, loss_trn(end), miscls_rate(end));
  %%  
  % H_0 = gamma*ones(1,DIM);
  %% L-BFGS two-loop recursion
  q = grad_f;
  alpha = zeros(1,length(S));
  for ii = length(S):-1:1
    alpha(ii) = rho(ii)*sum(S{ii}(:).*q(:));
    q = q - alpha(ii)*G{ii};
  end
  % r = H_0*q;
  r = gamma*q;
  for ii = 1:length(S)
    beta = rho(ii)*sum(G{ii}(:).*r(:));
    r = r + s*(alpha(ii)-beta);
  end
  p = -r;
  %% Line search
  t = 1;
  obj_tmp = fn_comp_obj(B,X,y);
  while 1
    obj_next_tmp = fn_comp_obj(B+t*p,X,y);
    if isnan(obj_next_tmp)
      t = BETA*t;
      continue;
    elseif obj_next_tmp <= obj_tmp + ALPHA*t*sum(grad_f(:).*p(:))
      break;
    end
    t = BETA*t;
  end
%   
  
%   while fn_comp_obj(B+t*p,X,y) > fn_comp_obj(B,X,y) + ALPHA*t*trace(grad_f.'*p) %||...
% %         isnan(fn_comp_obj(B+t*p,X,y))
%     t = BETA*t;
%   end
  %% Update
  B_next = B + t*p;
  grad_f_next = fn_comp_grad(B_next,X,y);
  s = B_next - B;
  g = grad_f_next - grad_f;
  gamma = sum(s(:).*g(:))/sum(g(:).*g(:));
  
  B = B_next;
  grad_f = grad_f_next;
  %% Save
  if length(S) >= m
    S = S(2:end);
    G = G(2:end);
    rho = rho(2:end);
  end
  S = [S, s];
  G = [G, g];
  rho = [rho, 1/sum(g(:).*s(:))];
  n_iter = n_iter+1;
end
fprintf(1,'||grad(f)||^2: %f\tl(B) (train): %f\t mis_cls_rate: %f\n', norm(grad_f(:),2)^2, loss_trn(end), miscls_rate(end));
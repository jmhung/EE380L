%% Problem discription
% Logistic regression
% min_{B}: f(B)

%%
clear;clc;close all;
%%
load logistic-digits
%% Data format
classes = sort(unique(y_train),'ascend');
[N_SAMPLE, DIM] = size(X_train);
N_CLASS = length(classes);
%% Paramters
TOL    = 1e-0; % Stopping criterion
MAX_ITER = 100;
ALPHA  = 0.4;  % BTLS parameter
BETA   = 0.8;  % BTLS parameter
B_init = rand([DIM, N_CLASS]); % Logit-reg. weights
m = 4; % # of secant vectors to be stored (L-BFGS)
%%
X_trn = cell(N_CLASS,1);
y_trn = cell(N_CLASS,1);
X_tst = cell(N_CLASS,1);
y_tst = cell(N_CLASS,1);
for ii = 1:N_CLASS
  X_trn{ii} = X_train(y_train == classes(ii),:);
  y_trn{ii} = y_train(y_train == classes(ii));
  X_tst{ii} = X_test(y_test == classes(ii),:);
  y_tst{ii} = y_test(y_test == classes(ii));
end
%% 
global XXX CCC X_CLASS
XXX = X_train;
CCC = N_CLASS;
X_CLASS = zeros(N_CLASS,DIM);
for cls = 1:N_CLASS
  X_CLASS(cls, :) = sum(X_trn{cls},1);
end
%% 1. Gradient Descent Method
[B, obj_f_GD, elpased_time_GD] = ...
    fn_GD(B_init, X_train, y_train, TOL, MAX_ITER, ALPHA, BETA);
%% 2. Accelerated Gradient Descent
[B, obj_f_AGD, loss_tst_AGD, miscls_rate_AGD, elapsed_time_AGD] = ...
    fn_Accel_GD(B_init, X_train, y_train, X_test, y_test, TOL, ALPHA, BETA, 0, N_SAMPLE);
%% 3. BFGS Medthod
[B, obj_f_BFGS, loss_tst_BFGS, miscls_rate_BFGS, elpased_time_BFGS] = ...
    fn_BFGS(B_init, X_train, y_train, X_test, y_test, TOL, MAX_ITER, ALPHA, BETA);
%% 4. L-BFGS Method
[B, obj_f_LBFGS, loss_tst_LBFGS, miscls_rate_LBFGS, elpased_time_LBFGS] = ...
  fn_LBFGS(B_init, X_train, y_train, X_test, y_test, TOL, MAX_ITER, ALPHA, BETA, m);
%% Figure 1. Performance vs. Iteration #
figure;
loglog(obj_f_GD,    '-o'); hold on;
loglog(obj_f_AGD,   '-x');
loglog(obj_f_LBFGS, '-s');
loglog(obj_f_BFGS,  '-*'); hold off;
grid on;
title('GD vs. AGD vs. L-BFGS vs. BFGS');
xlabel('Iteration'); ylabel('f(B^{(t)})');
legend('Gradient Descent', 'Accelerated Gradient Descent', 'L-BFGS (m=4)', 'BFGS');
%% Figure 2. Performance vs. Wall Time
figure;
loglog(elpased_time_GD,    obj_f_GD,    '-o'); hold on;
loglog(elapsed_time_AGD,   obj_f_AGD,   '-x');
loglog(elpased_time_LBFGS, obj_f_LBFGS, '-s');
loglog(elpased_time_BFGS,  obj_f_BFGS,  '-*'); hold off;
grid on;
title('GD vs. AGD vs. L-BFGS vs. BFGS');
xlabel('wall time (sec.)'); ylabel('f(B^{(t)})');
legend('Gradient Descent', 'Accelerated Gradient Descent', 'L-BFGS (m=4)', 'BFGS');